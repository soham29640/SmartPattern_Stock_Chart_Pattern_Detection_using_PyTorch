# Chart-pattern > 2024-03-18 11:51am
https://universe.roboflow.com/ebtihel/chart-pattern

Provided by a Roboflow user
License: CC BY 4.0

